package injection.sql;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

class AppTest {

    @Test
    void unSeulNom_trouverParNom_devraitRetournerLeLclient() {

        UtilisateurDAO utilisateur = new UtilisateurDAO();

        List<Utilisateur> listeObtenue = utilisateur.trouverParNom("BENDAOUD");

        assertEquals(1, listeObtenue.size(), "Doit contenir un utilisateur contenant le nom BENDAOUD");

    }

    @Test
    void deuxNomIdentiques_trouverParNom_devraitRetournerLesDeuxClients() {

        UtilisateurDAO utilisateur = new UtilisateurDAO();

        List<Utilisateur> listeObtenue = utilisateur.trouverParNom("BENDAOUD");

        assertEquals(2, listeObtenue.size(), "Doit contenir deux utilisateurs contenant le nom Bendaoud");
    }

    @Test
    void aucunNom_trouverParNom_devraitRetournerZeroClient() {

        UtilisateurDAO utilisateur = new UtilisateurDAO();

        List<Utilisateur> listeObtenue = utilisateur.trouverParNom("Jean");

        assertEquals(0, listeObtenue.size(), "Doit contenir aucun utilisateurs contenant le nom Jean");
    }

    @Test
    public void injectionSQL_trouverParNom_devraitRenvoyerzeroClient() {

        UtilisateurDAO utilisateurDAO = new UtilisateurDAO();

        List<Utilisateur> utilisateurs = utilisateurDAO.trouverParNom("pirate or '1' = '1'");

        assertEquals(0, utilisateurs.size(), "L'injection à réussi");
    }

}

package injection.sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UtilisateurDAO {

    public List<Utilisateur> trouverParNom(String nom) {

        Bdd bdd = new Bdd();
        Connection conn = bdd.connexion();

        // commande sql a éviter pour ne pas avoir d'injection SQL
        // le ('%s'",nom) sera la cause de l'injection SQL
        String sql = String.format("select id, prenom, nom, email from client where nom = '%s'", nom);
        // commande pour éviter une injection
        // String sql = String.format ("select ID_USER, Prenom, Nom, Email from user
        // where Nom = ?");
        // A chaque fois que l'on veut faire une entrée utilisateur on utilisera plutot
        // un "?" et pas une concaténation
        List<Utilisateur> utilisateurs = new ArrayList<>();

        try {
            // ceci est pas sécurisé
            Statement stmt = conn.createStatement();
            // les requête préparé sont recommandées pour éviter les injections
            // il faudrait mieux utilisé stmt = conn.preparedStatement(sql) pour éviter tout injection 
            //  et on va y ajouter cette commande suivante:
            // stmt.setString(1,nom);
            // donc cette commande va prendre le point ? qui va etre le 1 et on va lui
            // ajouter le nom qu'on va demander a l'utilisateur
            ResultSet res = stmt.executeQuery(sql);
            // pour plus de sécurité on va plus préféré:
            // ResultSet res = stmt.executeQuery();

            while (res.next()) {
                utilisateurs.add(contruireClientDepuis(res));
            }
            // si cela marche pas erreur
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        return utilisateurs;
    }

    private Utilisateur contruireClientDepuis(ResultSet res) throws SQLException {

        Long id = res.getLong("id");
        String prenom = res.getString("prenom");
        String nom = res.getString("nom");
        String email = res.getString("email");

        Utilisateur utilisateur = new Utilisateur(id, prenom, nom, email);

        return utilisateur;
    }

}

package injection.sql;

import java.sql.*;

public class Bdd {

    // connexion a la basse de donnée
    String url = "jdbc:mysql://localhost:3307/bddinjection?useUnicode=true"
            + "&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&" + "serverTimezone=UTC";
    String user = "root";
    String passwd = "";

    public Connection connexion() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(url, user, passwd);
            System.out.println("Connexion réussi");
            return con;
        }
        catch (SQLException e) {
            System.out.println("Connexion échoué");
            return con;
        }
    }
}

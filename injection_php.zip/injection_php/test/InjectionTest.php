<?php 

class InjectionTest extends \PHPUnit\Framework\TestCase
{
    public function test_unNomUnique_trouverUtilisateur_devraitRetournerLeLclient()
    {
        $bdd = new Model\Bdd();
        $utilisateur = new Controller\Nom('Bendaoud');
        $this->assertEquals(1,'Ligne de commande pour savoir si $utilisateur contient le nom Bendaoud','il doit contenir le nom pluchart');
    }

    public function test_deuxNomIdentique_trouverParNom_devraitRetournerLesDeuxClients(){

        $bdd = new Model\Bdd();
        $utilisateur = new Controller\Nom('Bendaoud');
        $this->assertEquals(2,'Ligne de commande pour savoir si $utilisateur contient deux fois le nom Bendaoud','il doit contenir deux fois le nom Bendaoud');
    }

    public function test_aucunNom_trouverParNom_devraitRetournerZeroClient()
    {
        $bdd = new Model\Bdd();
        $utilisateur = new Controller\Nom('Jean');
        $this->assertEquals(0,'Ligne de commande pour savoir si $Nomueser contient le nom Jean','il ne doit avoir aucun utilisateur Jean');
    }

    public function test_injection_trouverparnom_devraitrenvoyerZeroClient(){

        $bdd = new Model\Bdd();
        $utilisateur = new Controller\Nom("Pirate or '1' = '1'");
        $this->assertEquals(0,'Ligne de commande pour savoir si $utilisateur contient le nom Jean','injection à réussi');
    }
}
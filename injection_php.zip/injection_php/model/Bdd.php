<?php
    
    class Bdd{
    
            // Constructeur pour la connexion à la bdd
            function __construct(){
            //essay de connexion a bdd
            try{
                $this->bdd = new PDO("mysql:dbname=bddinjection;host:localhost:3307","root","");
                echo 'connexion ok ';
            }
            catch(PDOException $e){
                echo $e->getmessage();
            }
                }
            
            //getter
            function getBdd(){
                return $this->bdd;
            }

    //requête avec potentiel injection SQL car non préparé
    function getRequeteNonSecurise($nom){
    $sql = ("select id, prenom, nom, email from client c where client like.'".$nom."'");
    $sth = $bdd->query($sql);
    return $sth;
    }

    function getRequeteSecurise($id, $prenom, $nom, $email){
    //requête sécurisé car vérification avec "?" et requête préparé
    $sql = "select id, prenom, nom, email from client c where Nom = ?";
    $req = $bdd->prepare($sql);
    $result = $req->execute(array(':ID_User' => $id, 
                                  ':Prenom' => $prenom,
                                  ':Nom' => $nom,
                                  'Email' => $email));
    return $req->fetch();
    }
}
?>
    